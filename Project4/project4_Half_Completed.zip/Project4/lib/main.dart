import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(AnimationApp());
}

class AnimationApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Animation Viewer',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int? selectedIndex; // Stores the selected animation index
  bool isPlaying = false; // Tracks if an animation is playing
  String animationName = "No animation currently playing"; // Status text

  final List<String> animations = [
    "Bouncing",
    "Rotating",
    "Spinning",
    "Fading",
    "Scaling",
    "Sliding"
  ]; // List of animations

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Animato',
          style: GoogleFonts.pressStart2p(
            color: Colors.amber,
            fontSize: 25,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            padding: EdgeInsets.all(10),
            icon: const Icon(Icons.refresh_sharp, color: Colors.amber,size: 35.0,),
            onPressed: resetApp,
          ),
        ],
        centerTitle: true,
        flexibleSpace: FlexibleSpaceBar(
          background: Image.asset(
            'assets/appback.jpg', // Path to the background image
            fit: BoxFit.cover, // Ensures the image covers the AppBar area
          ),
        ),
        backgroundColor: Colors.transparent, // Transparent to see the background image
        elevation: 0, // Removes shadow for a cleaner look
      ),
        body: Container(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
          color: Color(0xDD1E2023), // Set the background color here
          child: Row(
            children: [
              // Left-side widget (List of animations)
              Expanded(
                flex: selectedIndex == null ? 1 : 1,
                child: ListView.builder(

                  itemCount: animations.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () => selectAnimation(index),
                      child: Container(
                        height: 80,
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: selectedIndex == index
                              ? Colors.blue.shade200
                              : Color(0xDD1E2023),
                          border: Border.all(
                            color: selectedIndex == index
                                ? Colors.blue
                                : Color(0xDD1E2023),
                          ),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: selectedIndex == index
                              ? [
                            BoxShadow(
                              color: Colors.blue.shade100,
                              blurRadius: 5,
                              spreadRadius: 2,
                            )
                          ]
                              : [],
                        ),
                        child: Container(
                          padding: const EdgeInsets.fromLTRB(16, 10, 10, 10), // Add more left padding
                          child: Text(
                            animations[index],
                            textAlign: TextAlign.left,
                            style: GoogleFonts.bizUDPGothic(
                              textStyle: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: selectedIndex == index
                                    ? Colors.blue.shade900
                                    : Colors.amber,
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              // Right-side widget (Selected animation)
              if (selectedIndex != null)
                Expanded(
                  flex: 2,
                  child: Container(
                    color: Colors.grey.shade200,
                    child: Center(
                      child: displayAnimation(selectedIndex!),
                    ),
                  ),
                ),
            ],
          ),
        ),
    );
  }

  void resetApp() {
    setState(() {
      selectedIndex = null;
      animationName = "No animation currently playing";
    });
  }

  void selectAnimation(int index) {
    setState(() {
      selectedIndex = index;
      animationName = "${animations[index]} is playing";
    });
  }

  Widget displayAnimation(int index) {
    // Placeholder for animations
    return Text(
      "Animation: ${animations[index]}",
      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
    );
  }
}
